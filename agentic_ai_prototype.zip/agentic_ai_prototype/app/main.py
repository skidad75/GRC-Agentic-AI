
import streamlit as st
from app.agent_router import route_query

st.set_page_config(page_title="Providence Agentic AI", layout="wide")

st.markdown("## 🧠 Providence Agentic AI Prototype")
query = st.text_input("Ask a question about architecture, risk, or compliance:")

if query:
    with st.spinner("Thinking..."):
        result = route_query(query)
        st.markdown(f"**🔎 Routed to:** `{result['agent'].upper()} Agent`")
        st.markdown("**📋 Response:**")
        st.markdown(result["response"])
